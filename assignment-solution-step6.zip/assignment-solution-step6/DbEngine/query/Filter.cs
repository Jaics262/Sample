﻿namespace DbEngine.Query
{
    //This class contains methods to evaluate expressions
    public class Filter
    {
        /* 
	 The evaluateExpression() method of this class is responsible for evaluating the expressions mentioned in the query.
     It has to be noted that the process of evaluating expressions will be 
     different for different data types. there are 6 operators that can exist within a query i.e. >=,<=,<,>,!=,= This method should be able
     to evaluate all of them. 
     Note: while evaluating string expressions, please handle uppercase and lowercase 
	 */

        //Method containing implementation of equalTo operator


        //Method containing implementation of notEqualTo operator


        //Method containing implementation of greaterThan operator


        //Method containing implementation of greaterThanOrEqualTo operator


        //Method containing implementation of lessThan operator


        //Method containing implementation of lessThanOrEqualTo operator

    }
}
