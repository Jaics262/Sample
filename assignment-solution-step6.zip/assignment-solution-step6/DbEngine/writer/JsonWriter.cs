﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DbEngine.writer
{
    /*
	 * this method will write the resultSet object into a JSON file. On successful
	 * writing, the method will return true, else will return false
	 */
    class JsonWriter
    {
        public bool WriteToJson()
        {
            return true;
        }
    }
}
